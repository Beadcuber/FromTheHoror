# FromTheHorror (Fabric 1.20.1)
Needs: JDK 17, Gradle 8.5+, Fabric API 0.92.2+1.20.1 at runtime.
Build:  gradle build     -> build/libs/FromTheHorror-1.0.0.jar
Put the jar plus Fabric API in your mods folder.

Features: The Dweller (stalks in caves, freezes while watched, flees from a flashlight stare),
The Watcher (still figure at night, vanishes if stared at),
Flashlight (craft glass pane / iron ingot / redstone vertically; right click toggles; repair on anvil with redstone),
dread events (darkness fog, footsteps behind you, whispers),
Buddy (/buddy hello, /buddy voice off) with built-in OS text-to-speech.
Admin: /horror spawn dweller|watcher, /horror event
Linux TTS needs espeak installed; Windows and macOS work out of the box.

## Building without installing anything
Push this folder to a GitHub repo. The Actions tab runs "Build FromTheHorror" and attaches the jar
(FromTheHorror-jar artifact). Use the jar WITHOUT "-sources" in its name.
Requires Fabric Loader 0.15+ and Fabric API for 1.20.1 (this is a Fabric mod, not Forge).
